package com.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.TopDao;
import com.entity.Tops;

/**
 * 商品推荐服务
 */

public interface TopService {
	
	
	/**
	 * 获取列表
	 * @return
	 */
	public List<Tops> getList(byte type, int page, int size);
	
	/**
	 * 获取总数
	 * @param type
	 * @return
	 */
	public long getTotal(byte type);
	
	/**
	 * 获取列表
	 * @return
	 */
	public List<Tops> getListByGoodid(int goodid);

	/**
	 * 通过id查询
	 * @param id
	 * @return
	 */
	public Tops get(int id);
	
	/**
	 * 添加
	 * @param top
	 * @return
	 */
	public Integer add(Tops top);

	/**
	 * 更新
	 * @param top
	 */
	public boolean update(Tops top);

	/**
	 * 删除
	 * @param top
	 */
	public boolean delete(Tops top);
	
	/**
	 * 按商品删除
	 * @param goodid
	 * @return
	 */
	public boolean deleteByGoodid(int goodid);
	
}
