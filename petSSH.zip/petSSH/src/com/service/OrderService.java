package com.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.OrderDao;
import com.entity.Orders;
import com.entity.Items;
import com.entity.Goods;

/**
 * 商品订单服务
 */

public interface OrderService {

	
	/**
	 * 创建订单
	 * @param good
	 * @return
	 */
	public Orders add(Goods good);
	
	/**
	 * 创建订单项
	 * @param good
	 * @return
	 */
	public Items addItem(Goods good);
	
	/**
	 * 向订单添加项目
	 * @param order
	 * @param good
	 * @return
	 */
	public Orders addOrderItem(Orders order, Goods good);
	
	/**
	 * 从订单中减少项目
	 * @param order
	 * @param good
	 * @return
	 */
	public Orders lessenIndentItem(Orders order, Goods good);
	
	/**
	 * 从订单中删除项目
	 * @param order
	 * @param good
	 * @return
	 */
	public Orders deleteIndentItem(Orders order, Goods good);
	
	/**
	 * 保存订单
	 * @param order
	 */
	public int save(Orders order);
	
	/**
	 * 订单支付
	 * @param order
	 */
	public void pay(Orders order);
	
	/**
	 * 获取订单列表
	 * @param page
	 * @param row
	 * @return
	 */
	public List<Orders> getList(byte status, int page, int row);
	
	/**
	 * 获取总数
	 * @return
	 */
	public int getTotal(byte status);

	/**
	 * 订单发货
	 * @param id
	 * @return 
	 */
	public boolean dispose(int id);
	
	/**
	 * 订单完成
	 * @param id
	 * @return 
	 */
	public boolean finish(int id);

	/**
	 * 删除订单
	 * @param id
	 */
	public boolean delete(int id);
	
	/**
	 * 获取某用户全部订单
	 * @param userid
	 */
	public List<Orders> getListByUserid(int userid);

	/**
	 * 通过id获取
	 * @param orderid
	 * @return
	 */
	public Orders get(int orderid);
	
	
	/**
	 * 获取订单项目列表
	 * @param orderid
	 * @return
	 */
	public List<Items> getItemList(int orderid);
	
}
