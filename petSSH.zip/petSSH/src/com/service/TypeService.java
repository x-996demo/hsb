package com.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.TypeDao;
import com.entity.Types;

/**
 * 类型服务
 */

public interface TypeService {

	
	/**
	 * 获取列表
	 * @return
	 */
	public List<Types> getList();

	/**
	 * 通过id查询
	 * @param id
	 * @return
	 */
	public Types get(int id);
	
	/**
	 * 添加
	 * @param type
	 * @return
	 */
	public Integer add(Types type);

	/**
	 * 更新
	 * @param type
	 */
	public boolean update(Types type);

	/**
	 * 删除
	 * @param type
	 */
	public boolean delete(Types type);
	
}
