package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.GoodDao;
import com.entity.Goods;
import com.entity.Tops;

/**
 * 商品服务
 */

public interface GoodService {

	
	/**
	 * 获取列表
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getList(int status, int page, int size);

	/**
	 * 获取产品总数
	 * @return
	 */
	public long getTotal(int status);
	
	/**
	 * 通过名称获取产品列表
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getListByName(String name, int page, int size);
	
	
	/**
	 * 通过名称获取产品总数
	 * @return
	 */
	public long getTotalByName(String name);
	
	/**
	 * 通过分类搜索
	 * @param typeid
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getListByType(int typeid, int page, int size);
	
	/**
	 * 获取数量
	 * @param typeid
	 * @return
	 */
	public long getTotalByType(int typeid);
	
	
	/**
	 * 通过id获取
	 * @param productid
	 * @return
	 */
	public Goods get(int id);
	
	/**
	 * 添加
	 * @param product
	 */
	public Integer add(Goods good);


	/**
	 * 修改
	 * @param product
	 * @return 
	 */
	public boolean update(Goods good);
	
	/**
	 * 删除商品
	 * 先删除此商品的推荐信息
	 * @param product
	 */
	public boolean delete(Goods good);
	

	/**
	 * 封装商品推荐信息
	 * @param list
	 * @return
	 */
	public List<Goods> packTopList(List<Goods> list);
	

	/**
	 * 封装商品推荐信息
	 * @param good
	 * @return
	 */
	public Goods packTop(Goods good);

}