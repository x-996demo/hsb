package com.dao;

import java.io.Serializable;

import javax.annotation.Resource;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


public interface BaseDao {
	
	public SessionFactory getSessionFactory();
	
	public void setSessionFactory(SessionFactory sessionFactory);
	public Session getSession();
	public void setSession(Session session);
	
	
	/**
	 * 主键查询
	 * @param clazz
	 * @param id
	 * @return 无记录返回null
	 */
	public <T> T get(Class<T> clazz, Serializable id);
	
	/**
	 * 添加
	 * @param object
	 * @return 返回主键
	 */
	public Integer save(Object object);
	
	/**
	 * 修改 实体无主键时抛StaleStateException
	 * @param object
	 * @return
	 */
	public boolean update(Object object);
	
	/**
	 * 删除 实体无主键时不执行, 直接返回true
	 * @param object
	 * @return
	 */
	public boolean delete(Object object);

}