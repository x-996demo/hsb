package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Types;


public interface TypeDao extends BaseDao{

	
	/**
	 * 获取列表
	 * @return
	 */
	public List<Types> getList();

}