package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Tops;


public interface TopDao extends BaseDao{

	/**
	 * 获取列表
	 * @return
	 */
	public List<Tops> getList(byte type, int page, int size);

	/**
	 * 获取总数
	 * @param type
	 * @return
	 */
	public long getTotal(byte type);
	
	/**
	 * 通过商品id获取
	 * @param goodid
	 * @return
	 */
	public List<Tops> getListByGoodid(int goodid);
	
	/**
	 * 通过商品id和类型删除
	 * @param goodid
	 * @param type
	 * @return
	 */
	public boolean deleteByGoodidAndType(int goodid, byte type);
	
	/**
	 * 通过goodid删除
	 * @param goodid
	 * @return
	 */
	public boolean deleteByGoodid(int goodid);

}