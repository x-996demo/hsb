package com.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.dao.GoodDao;
import com.entity.Goods;

@Repository // 注册dao层bean等同于@Component
public class GoodDaoImpl extends BaseDaoImp implements GoodDao{

	
	/**
	 * 获取列表
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getList(int page, int size){
		return getSession().createQuery("from Goods order by id desc", Goods.class)
				.setFirstResult((page-1)*size).setMaxResults(size).list();
	}
	
	/**
	 * 获取总数
	 * @return
	 */
	public long getTotal(){
		return getSession().createQuery("select count(*) from Goods", Long.class).uniqueResult();
	}
	
	/**
	 * 通过类型获取列表
	 * @param typeid
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getListByType(int typeid, int page, int size){
		return getSession().createQuery("from Goods where type_id=:typeid order by id desc", Goods.class)
				.setParameter("typeid", typeid).setFirstResult((page-1)*size).setMaxResults(size).list();
	}
	
	/**
	 * 通过类型获取总数
	 * @param typeid
	 * @return
	 */
	public long getTotalByType(int typeid){
		return (Long) getSession().createQuery("select count(*) from Goods where type_id=:typeid")
				.setParameter("typeid", typeid).uniqueResult();
	}
	
	/**
	 * 通过名称获取列表
	 * @param name
	 * @param page
	 * @param size
	 * @return
	 */
	public List<Goods> getListByName(String name, int page, int size){
		return getSession().createQuery("from Goods where name like :name order by id desc", Goods.class)
				.setParameter("name", "%"+name+"%").setFirstResult((page-1)*size).setMaxResults(size).list();
	}
	
	/**
	 * 通过名称获取总数
	 * @param name
	 * @return
	 */
	public long getTotalByName(String name){
		return getSession().createQuery("select count(*) from Goods where name like :name", Long.class)
				.setParameter("name", "%"+name+"%").uniqueResult();
	}
	
}