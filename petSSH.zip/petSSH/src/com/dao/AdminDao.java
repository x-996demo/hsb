package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Admins;


public interface AdminDao extends BaseDao{

	/**
	 * 通过用户名查找
	 * @param username
	 * @return
	 */
	public Admins getByUsername(String username);
	
	/**
	 * 通过用户名和密码查找
	 * @param username
	 * @param password
	 * @return 无记录返回null
	 */
	public Admins getByUsernameAndPassword(String username, String password);

	/**
	 * 获取列表
	 * @param page
	 * @param rows
	 * @return 无记录返回空集合
	 */
	public List<Admins> getList(int page, int rows);

	/**
	 * 总数
	 * @return
	 */
	public long getTotal();



}