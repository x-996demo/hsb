package com.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.entity.Orders;
import com.entity.Items;


public interface OrderDao extends BaseDao{

	/**
	 * 获取列表
	 * @param status
	 * @param page
	 * @param row
	 */
	public List<Orders> getList(byte status, int page, int rows);

	/**
	 * 获取总数
	 * @param status
	 * @return
	 */
	public long getTotal(byte status);

	/**
	 * 通过用户获取列表
	 * @param userid
	 */
	public List<Orders> getListByUserid(int userid);
	
	/**
	 * 订单项列表
	 * @param Ordersid
	 * @param page
	 * @param rows
	 * @return
	 */
	public List<Items> getItemList(int orderid);


}
