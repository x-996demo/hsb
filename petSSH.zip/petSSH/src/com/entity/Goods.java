package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity  // 注解为hibernate实体
@Table(name="goods") // 注解对应的表名
public class Goods {
	
	@Id	// 注解主键
	@GeneratedValue //id生成策略  默认auto 相当于hibernate的native - 自增字段
	private int id;
	private String name;
	private String cover;
	private String image1;
	private String image2;
	private int price;
	private String intro;
	private int stock;
	@ManyToOne
	@NotFound(action=NotFoundAction.IGNORE)
	private Types type;
	// 首页推荐标记

	@Transient // 不持久化
	private boolean topScroll; // 条幅推荐
	@Transient // 不持久化 
	private boolean topLarge; // 大图推荐
	@Transient // 不持久化
	private boolean topSmall; // 小图推荐
	
	
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCover() {
		return cover;
	}
	public void setCover(String cover) {
		this.cover = cover;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public Types getType() {
		return type;
	}
	public void setType(Types type) {
		this.type = type;
	}
	public boolean isTopScroll() {
		return topScroll;
	}
	public void setTopScroll(boolean topScroll) {
		this.topScroll = topScroll;
	}
	public boolean isTopLarge() {
		return topLarge;
	}
	public void setTopLarge(boolean topLarge) {
		this.topLarge = topLarge;
	}
	public boolean isTopSmall() {
		return topSmall;
	}
	public void setTopSmall(boolean topSmall) {
		this.topSmall = topSmall;
	}

	
}
